package com.iste.treasurehunt;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Clue5Activity extends AppCompatActivity {

    Button btnClue, btnNext;
    EditText edtClue, edtDispClue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clue5);
        edtClue = findViewById(R.id.edtClue);
        edtDispClue = findViewById(R.id.edtDispClue);
        edtDispClue.setKeyListener(null);
        btnClue = findViewById(R.id.btnClue);
        btnNext = findViewById(R.id.btnNext);
        btnClue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtClue.getText().toString().length() == 0){
                    edtClue.setError("Required");
                    return;
                }
                fetchClue();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtClue.getText().toString().length() == 0){
                    edtClue.setError("Required");
                    return;
                }
                startActivity(new Intent(Clue5Activity.this, Clue6Activity.class));
            }
        });
    }

    public void fetchClue() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait...");
        progressDialog.setMessage("Fetching Clue");
        progressDialog.setCancelable(true);
        progressDialog.show();

        String url = "https://meeky.xyz/iste/treasure%20hunt/treasurehuntwebservices/fetchClues5.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("response", response);
                progressDialog.dismiss();
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(response);
                    Toast.makeText(Clue5Activity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                    if(jsonObject.getInt("status") == 1) {
                        btnClue.setEnabled(false);
                        btnNext.setEnabled(true);
                        JSONArray jsonArray = jsonObject.getJSONArray("clue_array");
                        Log.i("response", response);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            jsonObject = jsonArray.getJSONObject(i);
                            String clue = jsonObject.getString("clue1");
                            edtDispClue.setText(clue);
                            edtDispClue.setMovementMethod(new ScrollingMovementMethod());
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.e("error", "error");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Log.e("error", "error in");

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> map = new HashMap<>();
                map.put("cl5", edtClue.getText().toString());
                return map;
            }
        };

        RetryPolicy retryPolicy = new DefaultRetryPolicy(3000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);

        VolleyApplication.getVolleyApplication().getRequestQueue().add(stringRequest);
    }
}
