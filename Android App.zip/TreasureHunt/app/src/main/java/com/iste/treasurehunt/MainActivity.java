package com.iste.treasurehunt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RadioGroup rgGroup;
    RadioButton rbParticipant, rbVolunteer;
    Button btnSubmit;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgGroup = (RadioGroup) findViewById(R.id.rgGroup);
        rbParticipant = (RadioButton) findViewById(R.id.rbParticipant);
        rbVolunteer = (RadioButton) findViewById(R.id.rbVolunteer);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(rgGroup.getCheckedRadioButtonId() == -1){
                    Toast.makeText(MainActivity.this, "Please select one of the option", Toast.LENGTH_SHORT).show();
                }
                else{
                    if(rbParticipant.isChecked()){
                        Intent i = new Intent(MainActivity.this, ParticipantActivity.class);
                        startActivity(i);
                    }
                    else if(rbVolunteer.isChecked()){
                        Intent i = new Intent(MainActivity.this, VolunteerActivity.class);
                        startActivity(i);
                    }
                }
            }
        });

    }
}